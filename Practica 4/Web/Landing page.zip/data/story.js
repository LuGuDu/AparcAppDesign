var story = {
 "docName": "Landing page",
 "docPath": "P_P_P",
 "docVersion": "V_V_V",
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "commentsURL": "V_V_C",
 "serverToolsPath": "",
 "fontSizeFormat": -1,
 "fileType": "jpg",
 "disableInteractions": false,
 "disableHotspots": false,
 "hideGallery": false,
 "zoomEnabled": true,
 "title": "Demo",
 "layersExist": true,
 "highlightLinks": true,
 "pages": [
  {
   "id": "1:2",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Producto",
   "image": "producto.jpg",
   "imageFull": "producto.jpg",
   "index": 0,
   "width": 1440,
   "height": 2553,
   "x": -720,
   "y": -513,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 0,
     "page": 2
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 73,
      "height": 20
     },
     "index": 1,
     "page": 4
    },
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 2,
     "page": 1
    },
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 3,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 26,
      "width": 70,
      "height": 20
     },
     "index": 4,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 93,
      "height": 20
     },
     "index": 5,
     "page": 4
    },
    {
     "rect": {
      "x": 783,
      "y": 1336,
      "width": 166,
      "height": 24
     },
     "index": 6,
     "page": 1
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "136:1432",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Funcionalidades",
   "image": "funcionalidades.jpg",
   "imageFull": "funcionalidades.jpg",
   "index": 1,
   "width": 1440,
   "height": 2657,
   "x": 820,
   "y": -513,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 7,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 26,
      "width": 70,
      "height": 20
     },
     "index": 8,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 57,
      "height": 20
     },
     "index": 9,
     "page": 4
    },
    {
     "rect": {
      "x": 301,
      "y": 26,
      "width": 62,
      "height": 20
     },
     "index": 10,
     "page": 0
    },
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 11,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 26,
      "width": 70,
      "height": 20
     },
     "index": 12,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 93,
      "height": 20
     },
     "index": 13,
     "page": 4
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "33:297",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Desarrollo",
   "image": "desarrollo.jpg",
   "imageFull": "full/desarrollo.jpg",
   "index": 2,
   "width": 1440,
   "height": 6155,
   "x": 2424,
   "y": -513,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 0,
     "y": 6083,
     "width": 1440,
     "height": 72,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [],
     "image": "desarrollo-0.jpg",
     "mskH": 72
    }
   ],
   "links": [
    {
     "rect": {
      "x": 538,
      "y": 28,
      "width": 71,
      "height": 20
     },
     "index": 14,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 28,
      "width": 70,
      "height": 20
     },
     "index": 15,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 28,
      "width": 57,
      "height": 20
     },
     "index": 16,
     "page": 4
    },
    {
     "rect": {
      "x": 395,
      "y": 28,
      "width": 111,
      "height": 20
     },
     "index": 17,
     "page": 1
    },
    {
     "rect": {
      "x": 538,
      "y": 28,
      "width": 71,
      "height": 20
     },
     "index": 18,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 28,
      "width": 70,
      "height": 20
     },
     "index": 19,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 28,
      "width": 93,
      "height": 20
     },
     "index": 20,
     "page": 4
    },
    {
     "rect": {
      "x": 538,
      "y": 28,
      "width": 71,
      "height": 20
     },
     "index": 21,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 28,
      "width": 70,
      "height": 20
     },
     "index": 22,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 28,
      "width": 57,
      "height": 20
     },
     "index": 23,
     "page": 4
    },
    {
     "rect": {
      "x": 301,
      "y": 28,
      "width": 62,
      "height": 20
     },
     "index": 24,
     "page": 0
    },
    {
     "rect": {
      "x": 395,
      "y": 28,
      "width": 111,
      "height": 20
     },
     "index": 25,
     "page": 1
    },
    {
     "rect": {
      "x": 538,
      "y": 28,
      "width": 71,
      "height": 20
     },
     "index": 26,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 28,
      "width": 70,
      "height": 20
     },
     "index": 27,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 28,
      "width": 93,
      "height": 20
     },
     "index": 28,
     "page": 4
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "106:907",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Prototipos",
   "image": "prototipos.jpg",
   "imageFull": "prototipos.jpg",
   "index": 3,
   "width": 1440,
   "height": 5753,
   "x": 3926,
   "y": -513,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 29,
     "page": 0,
     "disableAutoScroll": true
    },
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 30,
     "page": 2
    },
    {
     "rect": {
      "x": 301,
      "y": 26,
      "width": 62,
      "height": 20
     },
     "index": 31,
     "page": 0
    },
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 32,
     "page": 1
    },
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 33,
     "page": 1
    },
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 34,
     "page": 2
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 93,
      "height": 20
     },
     "index": 35,
     "page": 4
    },
    {
     "rect": {
      "x": 774,
      "y": 2600,
      "width": 142,
      "height": 24
     },
     "index": 36,
     "page": 3
    },
    {
     "rect": {
      "x": 775,
      "y": 5387,
      "width": 127,
      "height": 24
     },
     "index": 37,
     "page": 4
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "106:1191",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Pruebas",
   "image": "pruebas.jpg",
   "imageFull": "pruebas.jpg",
   "index": 4,
   "width": 1440,
   "height": 1877,
   "x": 5470,
   "y": -541,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 301,
      "y": 26,
      "width": 62,
      "height": 20
     },
     "index": 38,
     "page": 0
    },
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 39,
     "page": 0
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 72,
      "height": 20
     },
     "index": 40,
     "page": 4
    },
    {
     "rect": {
      "x": 395,
      "y": 26,
      "width": 111,
      "height": 20
     },
     "index": 41,
     "page": 1
    },
    {
     "rect": {
      "x": 538,
      "y": 26,
      "width": 71,
      "height": 20
     },
     "index": 42,
     "page": 2
    },
    {
     "rect": {
      "x": 641,
      "y": 26,
      "width": 70,
      "height": 20
     },
     "index": 43,
     "page": 3
    },
    {
     "rect": {
      "x": 743,
      "y": 26,
      "width": 93,
      "height": 20
     },
     "index": 44,
     "page": 4
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  }
 ],
 "groups": [
  {
   "id": "0:1",
   "name": "Page 1"
  }
 ],
 "startPageIndex": 2,
 "totalImages": 5
}